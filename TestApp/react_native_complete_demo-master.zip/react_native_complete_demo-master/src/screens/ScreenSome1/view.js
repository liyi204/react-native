import React from 'react';
import { View, Text } from 'react-native';

export default self => (
  <View>
    <Text style={{ fontSize: 36 }}>some1</Text>
  </View>
);
