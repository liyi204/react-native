import React from 'react';
import { View, Button, Text, TextInput } from 'react-native';
import styles from './style';

export default self => (
  <View style={{ alignItems: 'center' }}>
    <Text style={{ fontSize: 24 }}>历史上的今天</Text>

  </View>
);
