import React from 'react';
import { View, Text, Button } from 'react-native';


export default self => (
  <View>
    <Text style={{ fontSize: 22 }}>我的名字是：</Text>
    <Text style={{ fontSize: 1111 }}>我的性别是：</Text>
  </View>
);
