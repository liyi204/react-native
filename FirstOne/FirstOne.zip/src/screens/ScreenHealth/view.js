import React from 'react';
import { ImageBackground } from 'react-native';
import pxToDp from '../../config/pxToDp';

export default self => (
  <ImageBackground source={require('../../assets/images/Health.png')} style={{width: '100%', height: '100%',flex: 1}}> 
  </ImageBackground>
);
