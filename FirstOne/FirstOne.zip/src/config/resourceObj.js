export default ()=>{
    return {
        user_id:"10009",
        page_name:"",
        from_page:"",
        country:"Indonesia",
        city:"",
        type:"router",
        ip:"",
        name:"",
        create_time:Date.now()
    }
}