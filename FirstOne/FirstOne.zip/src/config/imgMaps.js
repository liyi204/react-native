export default {
    "p_1":require('../assets/images/PRUwealth.png'),
    "p_2":require('../assets/images/PRUwithyou.png'),
    "p_3":require('../assets/images/PRUwealthgain.png'),
    "p_4":require('../assets/images/PRUsmartgain.png'),

    "p_d_1":require('../assets/images/D_PRUwealth.png'),
    "p_d_2":require('../assets/images/D_PRUwithyou.png'),
    "p_d_3":require('../assets/images/D_PRUwealthgain.png'),
    "p_d_4":require('../assets/images/D_PRUsmartgain.png')

}