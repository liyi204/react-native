import React from 'react';
import Main from './src/config/route';

export default class App extends React.Component {
  render() {
    return <Main />;
  }
}
